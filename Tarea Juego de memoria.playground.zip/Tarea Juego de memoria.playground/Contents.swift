import UIKit
/*Tearea Juego de Memoria
 Por: Emilio Ceballos Sterling
 */

let rango = 0...100 //genera un rango de 0 a 100
var texto : String = "" //genera una variable que guarda las condiciones que cumple un numero


for i in rango{ //ciclo for para iterar los elementos del rango
    
    if i%2 == 0 {
        texto += "par!!!" //regla: “Si el número es par, imprime: # el número + “par!!!”
    }
    
    if i%5 == 0 {
        texto += "Bingo!!!" //regla: “Si el número es divisible entre 5, imprime: # el número  + “Bingo!!!”
    }
    
    if i < 40 && i > 30 {
        texto += "Viva Swift!!!" //regla: “Si el número se encuentra dentro de un rango del 30 al 40, imprime: # el número +  “Viva Swift!!!”
    }
    
    if i%2 == 1 {
        texto += "impar!!!" //Si el número es impar, imprime: # el número + “impar!!!”
    }
    
    print("\(i)" + texto) //impresion del texto con interpolacion de variables
    texto = ""  //reinicio de variable de condiciones
 
}



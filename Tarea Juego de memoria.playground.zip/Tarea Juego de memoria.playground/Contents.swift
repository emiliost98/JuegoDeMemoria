import UIKit

var rango = 0...100
var texto : String = ""
var impresion : [String] = []

for i in rango{
    //
    if i%2 == 0 {
        texto += "par!!!"
    }
    
    if i%5 == 0 {
        texto += "Bingo!!!"
    }
    
    if i < 40 && i > 30 {
        texto += "Viva Swift!!!"
    }
    
    if i%2 == 1 {
        texto += "impar!!!"
    }
    
    print("\(i) \(texto) ")
    texto = ""
 
}


